from setuptools import setup, find_packages
setup(
    name='utils',
    packages=find_packages()
)
