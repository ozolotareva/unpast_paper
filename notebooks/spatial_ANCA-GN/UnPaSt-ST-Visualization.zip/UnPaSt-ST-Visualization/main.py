import scanpy as sc
import squidpy as sq
import numpy as np
import pandas as pd
import gzip
import matplotlib.pyplot as plt

samples = [
    "V2_B",
    "V4_B",
    "V4_C",
    "V6_A",
]
tissue_position_files = {
    "V4_B": "GSM7974475_V4_B_tissue_positions.csv.gz",
    "V6_A": "GSM7974480_V6_A_tissue_positions.csv.gz",
    "V2_B": "GSM7974490_V2_B_tissue_positions.csv.gz",
    "V4_C": "GSM7974493_V4_C_tissue_positions.csv.gz",
}

# Sample-specific pie chart size factors
pie_size_factors = {
    "V2_B": 0.025,  # Standard size for V2
    "V4_B": 0.01,  # Smallest for V4 samples
    "V4_C": 0.015,  #
    "V6_A": 0.008,  # Smaller for V6
}


# Load the main AnnData object once
adata = sc.read_h5ad("./data/GSE250138_anca_and_ctrl_samples_processed.h5ad")


def plot_spatial_biclusters(
    adata,
    tissue_positions,
    bicluster_matrix_fractions,
    sample_id="V2_B",
    figsize=(12, 10),
    pie_size_factor=0.015,
    adaptive_sizing=True,
):
    """
    Plot spatial visualization with pie charts showing bicluster composition.

    Parameters:
    - adata: AnnData object with spatial coordinates
    - tissue_positions: DataFrame with tissue position data
    - bicluster_matrix_fractions: DataFrame with bicluster fractions per spot
    - sample_id: Sample identifier for library_id
    - figsize: Figure size tuple
    - pie_size_factor: Factor to scale pie chart size (fraction of coordinate range)
    - adaptive_sizing: If True, adjust size based on tissue density and scaling
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Get spots in tissue
    in_tissue_spots = tissue_positions[tissue_positions["in_tissue"] == 1]
    adata_in_tissue = adata[adata.obs["in_tissue"] == "1", :].copy()

    # Calculate crop coordinates
    crop_coords = [
        adata_in_tissue.obs["pxl_col_in_fullres"].min() - 100,
        adata_in_tissue.obs["pxl_row_in_fullres"].min() - 100,
        adata_in_tissue.obs["pxl_col_in_fullres"].max() + 100,
        adata_in_tissue.obs["pxl_row_in_fullres"].max() + 100,
    ]

    # Create background with tissue image
    ax = sq.pl.spatial_scatter(
        adata,
        color="cluster_annot",
        size=0,
        palette="tab20",
        library_id=sample_id,
        fig=fig,
        ax=ax,
        crop_coord=tuple(crop_coords),
        return_ax=True,
        alpha=0.0,
        img_alpha=0.75,
    )

    # Define bicluster colors
    bicluster_colors = ["magenta","red","darkblue","gold","white"] # bicluster colors
    ###bicluster_colors = ['#900D09', '#d62728', '#d2d40b', "white"] # cluster colors 

    # Calculate coordinate system parameters
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    coord_range_x = xlim[1] - xlim[0]
    coord_range_y = ylim[0] - ylim[1]

    # Calculate adaptive pie size
    if adaptive_sizing:
        # Calculate tissue density (spots per unit area)
        tissue_area = len(in_tissue_spots)
        coord_area = coord_range_x * abs(coord_range_y)
        density_factor = tissue_area / coord_area if coord_area > 0 else 1

        # Adjust size based on density - higher density = smaller pies
        density_adjustment = 1 / (1 + np.log10(max(density_factor, 1)) * 0.5)

        # Also consider the coordinate range scale
        scale_adjustment = (
            min(coord_range_x, abs(coord_range_y)) / 1000
        )  # normalize to typical range

        pie_size = (
            min(coord_range_x, abs(coord_range_y))
            * pie_size_factor
            * density_adjustment
            * scale_adjustment
        )
    else:
        pie_size = min(coord_range_x, abs(coord_range_y)) * pie_size_factor

    crop_width = crop_coords[2] - crop_coords[0]
    crop_height = crop_coords[3] - crop_coords[1]
    scale_x = coord_range_x / crop_width
    scale_y = coord_range_y / crop_height

    # Add pie charts for each spot with biclusters
    from matplotlib.patches import Wedge

    for _, row in in_tissue_spots.iterrows():
        barcode = row.name
        x_orig = row["pxl_col_in_fullres"]
        y_orig = row["pxl_row_in_fullres"]

        # Transform coordinates
        x = (x_orig - crop_coords[0]) * scale_x + xlim[0]
        y = (y_orig - crop_coords[1]) * scale_y + ylim[1]

        # Add pie chart if spot has biclusters
        if barcode in bicluster_matrix_fractions.index:
            fractions = bicluster_matrix_fractions.loc[barcode].values

            if np.sum(fractions) > 0:
                start_angle = 0
                for frac, color in zip(fractions, bicluster_colors):
                    if frac > 0:
                        angle_span = frac * 360
                        end_angle = start_angle + angle_span

                        wedge = Wedge(
                            (x, y),
                            pie_size,
                            start_angle,
                            end_angle,
                            facecolor=color,
                            alpha=1.0,
                            edgecolor="white",
                            linewidth=0.5,
                            zorder=2,
                        )
                        ax.add_patch(wedge)
                        start_angle = end_angle
        else:
            wedge = Wedge(
                        (x, y),
                        pie_size,
                        0,
                        360,
                        facecolor="white",
                        alpha=0.5,
                        edgecolor="grey",
                        linewidth=0.5,
                        zorder=2,
                    )
            ax.add_patch(wedge)

    # Add legend
    from matplotlib.patches import Patch

    legend_elements = [
        Patch(facecolor=color, label=f"{bicluster}")
        for bicluster, color in zip(
            bicluster_matrix_fractions.columns, bicluster_colors
        )
    ]

    ax.legend(
        handles=legend_elements,
        loc="upper left",
        bbox_to_anchor=(1.02, 1),
        title="Biclusters",
        ###title="Clusters",
        fontsize=12,
    )

    plt.tight_layout()
    return fig, ax


# Iterate through all samples
for sample_id in samples:
    # Load bicluster data for current sample
    df_biclusters = pd.read_table(
        f"./data/ANCA_specific.{sample_id}.biclusters.tsv.gz", index_col=0
        ###f"./data/published.{sample_id}.clusters.tsv.gz", index_col=0
    )
    # Process bicluster data
    bicluster_data = df_biclusters["samples"].str.split(" ")
    unique_samples_set = set()
    for samples_list in bicluster_data:
        unique_samples_set.update(samples_list)
    unique_samples = sorted(unique_samples_set)
    columns = bicluster_data.index.values
    data = np.zeros((len(unique_samples), len(columns)), dtype=int)
    sample_to_index = {sample: idx for idx, sample in enumerate(unique_samples)}
    for col_idx, samples_list in enumerate(bicluster_data):
        for sample in samples_list:
            row_idx = sample_to_index[sample]
            data[row_idx, col_idx] = 1

    bicluster_matrix = pd.DataFrame(data, index=unique_samples, columns=columns)
    bicluster_matrix_fractions = bicluster_matrix.div(
        bicluster_matrix.sum(axis=1), axis=0
    )

    # Subset AnnData for current sample
    adata_sample = adata[adata.obs["Sample"] == sample_id].copy()
    adata_sample.obs_names = (
        adata_sample.obs_names.str.split("-").str[0]
        + "-"
        + adata_sample.obs_names.str.split("-").str[1]
    )

    # Load tissue positions for current sample
    tissue_position_file = tissue_position_files[sample_id]
    with gzip.open(f"./data/{tissue_position_file}") as f:
        tissue_positions = pd.read_csv(f)

    tissue_positions["barcode"] = tissue_positions["barcode"].apply(
        lambda x: f"{x}_{sample_id}"
    )
    tissue_positions.set_index("barcode", inplace=True)

    # Add spatial coordinates to AnnData
    adata_sample.obs["pxl_row_in_fullres"] = tissue_positions["pxl_row_in_fullres"]
    adata_sample.obs["pxl_col_in_fullres"] = tissue_positions["pxl_col_in_fullres"]

    adata_sample.obsm["spatial"] = np.column_stack(
        [
            adata_sample.obs["pxl_col_in_fullres"].values,
            adata_sample.obs["pxl_row_in_fullres"].values,
        ]
    )

    # Get in-tissue spots
    adata_sample_in_tissue = adata_sample[
        adata_sample.obs["in_tissue"] == "1", :
    ].copy()
    in_tissue_spots = tissue_positions[tissue_positions["in_tissue"] == 1]

    # Create the plot for current sample with sample-specific pie size
    sample_pie_size = pie_size_factors.get(sample_id, 0.015)  # Default fallback
    fig, ax = plot_spatial_biclusters(
        adata_sample,
        tissue_positions,
        bicluster_matrix_fractions,
        sample_id=sample_id,
        pie_size_factor=sample_pie_size,
        adaptive_sizing=True,
    )
    ax.set_title(f"Biclusters - {sample_id}")

    # Save the plot
    output_filename = f"./figures/bicluster_plot_{sample_id}.pdf"
    ###output_filename = f"./figures/cluster_plot_{sample_id}.pdf"
    plt.savefig(output_filename, dpi=300, bbox_inches="tight")
    print(f"Saved plot: {output_filename}")
    plt.close()

print("All plots have been generated and saved!")
