# UnPaSt bicluster visualization

Visualization of bicluster fractions with pie charts.

### download GSE250138
cd data
wget https://ftp.ncbi.nlm.nih.gov/geo/series/GSE250nnn/GSE250138/suppl/GSE250138%5Fanca%5Fand%5Fctrl%5Fsamples%5Fprocessed%2Eh5ad
cd ..

### specify (bi)cluster file names, colors, and figure file names in main.py 

### run:
uv sync
uv run main.py # takes a while when running the first time

